import { AllRoutes } from "./routes/AllRoutes";

import './App.css';

function App() {
  return (
    <div className="App">
      <div><AllRoutes /></div>
    </div>
  );
}

export default App;
