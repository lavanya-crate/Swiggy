export const OfferHero = () => {
    return (
        <div className="mt-10 relative">
            <img className="h-auto w-[80%] mx-auto rounded-lg" src="../../../assets/images/offerhero.avif" alt=""></img>
            <span className="absolute font-serif font-bold text-start text-4xl leading-normal text-white bottom-20 left-48">Restaurants Near Me For Dining <br />out</span>
        </div>
    )
}
