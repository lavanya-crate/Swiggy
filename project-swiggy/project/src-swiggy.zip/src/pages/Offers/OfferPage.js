import { OfferHeader } from "./components/OfferHeader";
import { OfferHero } from "./components/OfferHero";

export const OfferPage = () => {
  return (
    <main>
        <OfferHeader />
        <OfferHero />
    </main>
  )
}
