import { Header } from "../../../components/Layouts/Header";
import { HotelDetail } from "./components/HotelDetail";
import { Recommended } from "./components/Recommended";
import { TopPicks } from "./components/TopPicks";

export const ItemsDetail = () => {
  return (
    <>
    <Header />
    <HotelDetail />
    <TopPicks />
    <Recommended />
    </>
  )
}
