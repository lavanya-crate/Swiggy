
import { HotelDetail } from "./components/HotelDetail";


export const ItemsDetail = () => {
  return (
    <>
    
    <HotelDetail />
    
    </>
  )
}
