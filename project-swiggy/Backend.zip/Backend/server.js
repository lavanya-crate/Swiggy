const express=require("express")
 
const app=express()
 
var cors=require("cors")
 
const port=5000;
 
var mysql=require("mysql")
 
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Lavanya@123",
    database: "swiggy"
});
 
 
// app.get("/",(req,res)=>(
//     res.send("server is running")
// ))

//Restaurant
app.get("/items", (req, res) => {
    const sql = "select * from Restaurant";
    con.query(sql, (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});

app.get("/items/:restaurantID", (req, res) => {
    const { restaurantID } = req.params;
    const sql = "select * from Restaurant where restaurantID = ?";
    con.query(sql,[restaurantID], (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});

app.post("/items", (req, res) => {
        const restaurantID = req.body.restaurantID;
        const addressID = req.body.addressID;
        const name = req.body.name;
        const rating = req.body.rating;
        const place = req.body.place;
        const time = req.body.time;
    
        const sql = "insert into Restaurant(restaurantID,addressID, name, rating, place, time) values(?,?,?,?,?,?)";
        con.query(sql, [restaurantID,addressID, name, rating, place, time], (err, data) => {
            if (err) return res.json("error");
            return res.json(data);
        })
    });

//User
app.get("/user", (req, res) => {
    const sql = "select * from User";
    con.query(sql, (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});


app.get("/user/:userID", (req, res) => {
    const { userID } = req.params;
    const sql = "select * from User where userID = ?";
    con.query(sql,[userID], (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});

//Menuitems
app.get("/menuitem", (req, res) => {
    const sql = "select * from menuitem";
    con.query(sql, (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});


app.get("/menuitem/:menuitemID", (req, res) => {
    const { menuitemID } = req.params;
    const sql = "select * from menuitem where menuitemID = ?";
    con.query(sql,[menuitemID], (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});

//Address
app.get("/address", (req, res) => {
    const sql = "select * from Address";
    con.query(sql, (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});


app.get("/address/:addressID", (req, res) => {
    const { addressID } = req.params;
    const sql = "select * from Address where addressID = ?";
    con.query(sql,[addressID], (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});
 

//DeliveryAgent
app.get("/deliveryagent", (req, res) => {
    const sql = "select * from deliveryagent";
    con.query(sql, (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});


app.get("/deliveryagent/:agent_id", (req, res) => {
    const { agent_id } = req.params;
    const sql = "select * from deliveryagent where agent_id = ?";
    con.query(sql,[agent_id], (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});
 
//Orders
app.get("/orders", (req, res) => {
    const sql = "select * from orders";
    con.query(sql, (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});


app.get("/orders/:order_id", (req, res) => {
    const { order_id } = req.params;
    const sql = "select * from orders where order_id = ?";
    con.query(sql,[order_id], (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});
 
//Review
app.get("/review", (req, res) => {
    const sql = "select * from review";
    con.query(sql, (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});


app.get("/review/:review_id", (req, res) => {
    const { review_id } = req.params;
    const sql = "select * from review where review_id = ?";
    con.query(sql,[review_id], (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});

//Order Status
app.get("/orderstatus", (req, res) => {
    const sql = "select * from orderstatus";
    con.query(sql, (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});


app.get("/orderstatus/:orderstatus_id", (req, res) => {
    const { orderstatus_id } = req.params;
    const sql = "select * from orderstatus where orderstatus_id = ?";
    con.query(sql,[orderstatus_id], (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});

//Payment
app.get("/payment", (req, res) => {
    const sql = "select * from payment";
    con.query(sql, (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});


app.get("/payment/:paymentid", (req, res) => {
    const { paymentid } = req.params;
    const sql = "select * from payment where paymentid = ?";
    con.query(sql,[paymentid], (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});
 
//Delivery Status
app.get("/deliverystatus", (req, res) => {
    const sql = "select * from deliverystatus";
    con.query(sql, (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});


app.get("/deliverystatus/:deliverystatus_id", (req, res) => {
    const { deliverystatus_id } = req.params;
    const sql = "select * from deliverystatus where deliverystatus_id = ?";
    con.query(sql,[deliverystatus_id], (err, data) => {
        if (err) return res.json("error");
        return res.json(data);
    });

});


app.listen(port,()=>{
    console.log(`server is ruuning http://localhost:${port}`)
})
 